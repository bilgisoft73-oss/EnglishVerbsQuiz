English Verbs Quiz - Android Studio project

Open this folder in Android Studio.
Use Build > Build APK(s).
The app works offline and loads app/src/main/assets/index.html in a WebView.
Package: com.hadi.englishverbsquiz
Min SDK: 23
Target/Compile SDK: 35
